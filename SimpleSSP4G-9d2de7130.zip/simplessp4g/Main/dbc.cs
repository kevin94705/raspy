﻿
using Oracle.ManagedDataAccess.Client;
using System.Configuration;
using System.Data.SqlClient;
using static simpleSSP4G.DbSessionBase;
using System.Data.Common;
using System;

namespace simpleSSP4G
{
    public class Dbc
    {
        public abstractDbSessionBase DbSession {  get; }
        public Dbc(string connName="")
        {
            DbSession = CreateDbSession(connName);
        }
        public abstractDbSessionBase CreateDbSession(string connName)
        {
            // 根据 connName 获取连接字符串
            ConnectionStringSettings connectionSettings = ConfigurationManager.ConnectionStrings[connName];            
            if (connectionSettings == null)
            {
                UtilityLog.ErrorLog($"未找到名為 '{connName}' 的連接字串。");
                throw new ArgumentException($"未找到名為 '{connName}' 的連接字串。");
            }
            string connectionString = connectionSettings.ConnectionString;
            string providerName = connectionSettings.ProviderName;
            if (providerName.Equals("System.Data.SqlClient", StringComparison.OrdinalIgnoreCase))
            {
                // 创建 SQL Server 数据库会话对象
                return new DbSessionBasic(connectionString);
            }
            else if (providerName.Equals("Oracle.ManagedDataAccess.Client", StringComparison.OrdinalIgnoreCase))
            {
                return new DbSessionOra(connectionString);
            }
            else 
            {
                UtilityLog.ErrorLog($"SimpleSSP4G沒有找到指定的providerName或是ConnectionStrings沒設定provider");
                throw new ArgumentException($"SimpleSSP4G沒有找到指定的providerName或是ConnectionStrings沒設定provider");
            }
            
        }
    }




    public class DbSessionOra : abstractDbSessionBase
    {
        public string seq = ":";
        //setting base value
        public DbSessionOra(string connectionString) : base(connectionString)
        {

        }
        public override DbStatement GetStatement(string sqlQuery="")
        {
            // Create a DbStatement instance with the provided SQL query
            return createNewStatement(sqlQuery);
        }


        protected override DbDataAdapter GetDbDataAdapter()
        {
            return new OracleDataAdapter();
        }

        protected override DbConnection NewConnection(string connectionString)
        {
            return new OracleConnection(connectionString);
        }
        internal DbStatement createNewStatement(string sqlQuery)
        {
            OracleCommand OracleCommand = new OracleCommand(sqlQuery);
            OracleCommand.BindByName = true;
            return new DbStatement(OracleCommand, new OraParameterCollection(OracleCommand.Parameters),seq);
        }
    }


    public class DbSessionBasic : abstractDbSessionBase
    {
        public string seq = "@";
        public DbSessionBasic(string connectionString) : base(connectionString)
        {
        }
        public override DbStatement GetStatement(string sqlQuery="")
        {
            // Create a DbStatement instance with the provided SQL query
            return createNewStatement(sqlQuery);
        }
       

        protected override DbDataAdapter GetDbDataAdapter()
        {
            return new SqlDataAdapter();
        }

        protected override DbConnection NewConnection(string connectionString)
        {
            return new SqlConnection(connectionString);
        }

        internal DbStatement createNewStatement(string sqlQuery)
        {
            SqlCommand sqlCommand = new SqlCommand(sqlQuery);
            return new DbStatement(sqlCommand, new SQLParameterCollection(sqlCommand.Parameters), seq);
        }
    }
    
    
}
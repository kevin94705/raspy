﻿using System;

namespace simpleSSP4G
{
    public class PropertyAttribute : Attribute
    {
        /// <summary>
        /// 必須是sql上顯示的欄位名稱
        /// </summary>
        public string Column { get; set; }
        public bool IsPrimaryKey { get; set; }
        /// <summary>
        /// 依情況添加
        /// </summary>
        public string Describing { get; set; }
    }
}
﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

namespace simpleSSP4G
{
    public class DbStatement
    {
        private DbCommand cmd;
        public abstractDbParameterCollection Parameters;
        public string Seq;
        public string SqlQuery { get; internal set; }

        public string CommandText
        {
            get
            {
                return this.cmd.CommandText;
            }
            set
            {
                this.cmd.CommandText = value;
            }
        }

        public CommandType CommandType
        {
            get
            {
                return this.cmd.CommandType;
            }
            set
            {
                this.cmd.CommandType = value;
            }
        }
        internal DbCommand DbCommand
        {
            get
            {
                return this.cmd;
            }
        }


        public OracleParameterCollection OracleParameters
        {
            get
            {
                if (this.cmd.Parameters.GetType() != typeof(OracleParameterCollection))
                {
                    throw new ArgumentException("当前DbSession不是Oracle.ManagedDataAccess.Client，不能调用DbStatement.OracleParameters属性。");
                }
                
                return (OracleParameterCollection)this.cmd.Parameters;
            }
        }



        public SqlParameterCollection SqlParameters
        {
            get
            {
                if (this.cmd.Parameters.GetType() != typeof(SqlParameterCollection))
                {
                    throw new ArgumentException("当前DbSession不是SqlClientSession，不能调用DbStatement.SqlParameters属性。");
                }
                return (SqlParameterCollection)this.cmd.Parameters;
            }
        }

        public DbStatement(DbCommand cmd, abstractDbParameterCollection col,string seq)
        {
            this.Parameters = col;
            this.cmd = cmd;           
            this.Seq = seq;
        }
    }
}

﻿using System;
using System.Web;

namespace simpleSSP4G
{
    public static class ApcProvider
    {
        private const string ApcKey = "__RequestScopedApc";

        public static Apc Current
        {
            get
            {
                var context = HttpContext.Current;
                if (context == null)
                    throw new InvalidOperationException("ApcProvider.Current must be used within an HTTP request.");

                // 檢查是否已有 Apc 實例
                if (context.Items[ApcKey] == null)
                {
                    // 如果沒有，初始化一個新的 Apc 並存到 context.Items
                    context.Items[ApcKey] = new Apc();

                    // 記錄 log - 新建 Apc 實例
                    UtilityLog.InfoLog("[ApcProvider] Created new Apc instance for this HTTP request.");
                }
                else
                {
                    // 記錄 log - 從 cache 中提取 Apc 實例
                    UtilityLog.InfoLog("[ApcProvider] Reusing cached Apc instance for this HTTP request.");
                }

                return (Apc)context.Items[ApcKey];
            }
        }

    }
}
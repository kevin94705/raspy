﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace simpleSSP4G
{
    /// <summary>
    /// entity CRUD 方法
    /// </summary>
    public abstract class AbstractEntityHelper
    {        
        private protected abstract IEnumerable<T> Select<T>(T e,T w) where T : class, new();        
        private protected abstract Task<IEnumerable<T>> SelectAsync<T>(T e,T w) where T : class, new();
        private protected abstract int Insert<T>(T e) where T : class, new();
        private protected abstract Task<int> InsertAsync<T>(T e) where T : class, new();        
        private protected abstract int Update<T>(T e,T w) where T : class, new();

        
        private protected abstract Task<int> UpdateAsync<T>(T e,T w) where T : class, new();
        
        private protected abstract int Delete<T>(T e,T w) where T : class, new();

        
        private protected abstract Task<int> DeleteAync<T>(T e,T w) where T : class, new();




    }
}
﻿using System;
using System.Configuration;
using System.Threading;
using NLog;

namespace simpleSSP4G
{
    public class UtilityLog
    {
        private static readonly Logger _logger = LogManager.GetCurrentClassLogger();
        private const int MaxRetries = 3;
        private const int RetryDelay = 100; // milliseconds

        private static void LogWithRetry(Action logAction)
        {
            for (int attempt = 1; attempt <= MaxRetries; attempt++)
            {
                try
                {
                    logAction();
                    return; // Log successful, exit the method
                }
                catch (Exception ex) when (ex.Message.Contains("The process cannot access the file"))
                {
                    if (attempt == MaxRetries)
                    {
                        // If all retries failed, log the error to console
                        Console.WriteLine($"Failed to log after {MaxRetries} attempts: {ex.Message}");
                    }
                    else
                    {
                        // Wait before next retry
                        Thread.Sleep(RetryDelay);
                    }
                }
            }
        }

        public static void InfoLog(string message)
        {
            LogWithRetry(() => _logger.Info(message));
        }

        public static void DebuggerLog(string message)
        {
            bool flag = ConfigurationManager.AppSettings["Debug"] == null ? false : Convert.ToBoolean(ConfigurationManager.AppSettings["Debug"]);
            if (!string.IsNullOrEmpty(message) && flag)
            {
                LogWithRetry(() => _logger.Debug(message));
            }
        }

        public static void ErrorLog(Exception ex)
        {
            ErrorLog("", ex);
        }

        public static void ErrorLog(string message)
        {
            LogWithRetry(() => _logger.Error(message));
        }

        public static void ErrorLog(string message, Exception ex)
        {
            LogWithRetry(() =>
            {
                if (string.IsNullOrEmpty(message))
                {
                    _logger.Error(ex, ex.Message+"\n"+ex.StackTrace);
                }
                else
                {
                    _logger.Error(ex, message + "\n"+ex.Message + "\n" + ex.StackTrace);
                }
            });
        }
    }
}
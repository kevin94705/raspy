﻿/*
 new Dbc() is a database connection object.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using static simpleSSP4G.EntityHelper;

namespace simpleSSP4G
{
    /// <summary>
    /// 設定dbc
    /// </summary>
    public class EntityDBBase:AbstractEntityHelper
    {
        public Dbc dbc;
        /// <summary>
        /// webconfig connection name 
        /// </summary>
        /// <param name="ConnName"></param>
        public EntityDBBase(string ConnName)
        {
            dbc = new Dbc(ConnName);
        }
        /// <summary>
        /// 第一參數SQL,透過第二參數 傳遞DbStatement設定的方法FUNC 來設定SQL 的parameter
        /// </summary>
        /// <param name="sql">SQL 查詢語句</param>
        /// <param name="parameterSetup">用於設置參數的可選 Action </param>
        /// <returns>查詢結果的 DataTable</returns>
        public DataTable ExecuteDataTableWithAction(string sql, Action<DbStatement> parameterSetup = null)
        {
            DbStatement stmt = dbc.DbSession.GetStatement(sql);

            parameterSetup?.Invoke(stmt);//執行外層CALL時傳入的方法NULL就不為執行委託FUNC

            return dbc.DbSession.ExecuteDataTable(stmt);
        }
        /// <summary>
        /// 第一參數SQL,透過第二參數 傳遞DbStatement設定的方法FUNC 來設定SQL 的parameter
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="parameterSetup"></param>
        /// <returns></returns>
        public int ExecuteNonQueryWithAction(string sql, Action<DbStatement> parameterSetup = null) {
            DbStatement stmt = dbc.DbSession.GetStatement(sql);
            parameterSetup?.Invoke(stmt);//執行外層CALL時傳入的方法NULL就不為執行委託FUNC
            return dbc.DbSession.ExecuteNonQuery(stmt);
        }
        /// <summary>
        /// 執行非同步查詢的方法，允許帶入參數的 SQL 管理
        /// </summary>
        /// <param name="initialSql">初始 SQL 查詢語句</param>
        /// <param name="setupAction">用於設置參數和修改 SQL 的 Action</param>
        /// <returns>查詢結果的 DataTable</returns>
        public async Task<DataTable> ExecuteDataTableWithActionAsync(string initialSql, Action<DbStatement, StringBuilder> setupAction)
        {
            DbStatement stmt = dbc.DbSession.GetStatement(initialSql);
            StringBuilder sqlBuilder = new StringBuilder(initialSql);

            setupAction(stmt, sqlBuilder);//執行外層CALL時傳入的方法NULL就不為執行委託FUNC

            stmt.DbCommand.CommandText = sqlBuilder.ToString();
            return await dbc.DbSession.ExecuteDataTableAsync(stmt);
        }
        public async Task<DataTable> ExecuteDataTableQueryAsync(string sql)
        {
            DbStatement stmt = dbc.DbSession.GetStatement(sql);
            return await dbc.DbSession.ExecuteDataTableAsync(stmt);
        }
        /// <summary>
        /// 透過entity helper 自動產SQL 必須維護好entity class 的column 與table 參數
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="Entity"></param>
        /// <returns></returns>
        private protected override IEnumerable<T> Select<T>(T Entity,T WhererCondition=null)
        {
            DbStatement stmt = dbc.DbSession.GetStatement();            
            stmt = DBTransationGenSQL(Entity, DBTransactionOperation.Select, stmt, GetWhereColumnsFromEntity(WhererCondition));            
            return ConvertDataTableToList<T>(dbc.DbSession.ExecuteDataTable(stmt));
        }
        /// <summary>
        /// 透過entity helper 自動產SQL 必須維護好entity class 的column 與table 與primarykey 參數  
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="Entity"></param>
        /// <returns></returns>
        private protected override int Insert<T>(T e)
        {
            return NonQueryCore(e, DBTransactionOperation.Insert, null);
        }
        /// <summary>
        /// 透過entity helper 自動產SQL 必須維護好entity class 的column 與table 與primarykey 參數  
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="Entity"></param>
        /// <returns></returns>
        private protected override int Update<T>(T e,T w=null)
        {
            return NonQueryCore(e, DBTransactionOperation.Update, w);
        }
        /// <summary>
        /// 透過entity helper 自動產SQL 必須維護好entity class 的column 與table 與primarykey 參數  
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="Entity"></param>
        /// <returns></returns>
        private protected override int Delete<T>(T e, T w)
        {
            return NonQueryCore(e, DBTransactionOperation.Delete,w);
        }

        /// <summary>
        /// 用於驗證entity 有設定DataAnnotations 的約束
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="e"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public ValueTuple<bool,string> ValidationEntity<T>(T e) 
        {
            var context = new ValidationContext(e);
            var results = new List<ValidationResult>();
            bool isValid = Validator.TryValidateObject(e, context, results, true);
            StringBuilder sb = new StringBuilder();
            if (!isValid)
            {
                
                foreach (var validationResult in results)
                {
                    sb.AppendLine($"屬性[{string.Join(", ", validationResult.MemberNames)}] 驗證失敗: {validationResult.ErrorMessage}");
                }
            }
            return (isValid, sb.ToString());
        }

        private protected override async Task<IEnumerable<T>> SelectAsync<T>(T Entity,T WhereCondition=null)
        {
            DbStatement stmt = dbc.DbSession.GetStatement();
            stmt = DBTransationGenSQL(Entity, DBTransactionOperation.Select, stmt,GetWhereColumnsFromEntity(WhereCondition));
            return ConvertDataTableToList<T>(await dbc.DbSession.ExecuteDataTableAsync(stmt));
        }
        private protected override async Task<int> InsertAsync<T>(T e) 
        {
            return await NonQueryCoreAsync(e, DBTransactionOperation.Insert,null);
        }
        private protected override async Task<int> UpdateAsync<T>(T e, T w = null)
        {
            return await NonQueryCoreAsync(e, DBTransactionOperation.Update, w);
        }

        private protected override async Task<int> DeleteAync<T>(T e, T w=null)
        {
            return await NonQueryCoreAsync(e, DBTransactionOperation.Delete, w);
        }
        private protected async Task<int> NonQueryCoreAsync<T>(T e, DBTransactionOperation operation, T w) where T:class ,new() 
        {
            DbStatement stmt = dbc.DbSession.GetStatement();            
            DBTransationGenSQL(e, operation, stmt, GetWhereColumnsFromEntity(w));
            return await dbc.DbSession.ExecuteNonQueryAsync(stmt);
        }
        private protected int NonQueryCore<T>(T e, DBTransactionOperation operation, T w) where T : class, new()
        {
            DbStatement stmt = dbc.DbSession.GetStatement();
            DBTransationGenSQL(e, operation, stmt, GetWhereColumnsFromEntity(w));
            return dbc.DbSession.ExecuteNonQuery(stmt);
        }

    }
    
}
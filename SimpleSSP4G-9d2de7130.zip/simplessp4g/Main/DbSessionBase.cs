﻿using System;
using System.Data;
using System.Data.Common;
using System.Diagnostics;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace simpleSSP4G
{
    public class DbSessionBase
    {
        public abstract class abstractDbSessionBase : IDisposable
        {
            private DbConnection conn = null;


            private DbTransaction trans = null;
            public abstractDbSessionBase(string connectionString)
            {
                this.conn = this.NewConnection(connectionString);
            }
            protected abstract DbConnection NewConnection(string connectionString);
            private void PrepareDbCommand(DbStatement stmt)
            {
                stmt.DbCommand.Connection = this.conn;
                if (stmt.DbCommand.Connection.State == ConnectionState.Closed)
                {
                    stmt.DbCommand.Connection.Open();
                }
                stmt.DbCommand.Transaction = this.trans;
            }
            private async Task PrepareDbCommandAsync(DbStatement stmt)
            {
                if (stmt == null)
                    throw new ArgumentNullException(nameof(stmt));

                try
                {
                    stmt.DbCommand.Connection = this.conn;
                    if (stmt.DbCommand.Connection.State == ConnectionState.Closed)
                    {
                        await stmt.DbCommand.Connection.OpenAsync();
                    }
                    stmt.DbCommand.Transaction = this.trans;
                }
                catch (Exception ex)
                {
                    UtilityLog.ErrorLog(ex);
                    throw;
                }
            }

            public void Dispose()
            {
                UtilityLog.DebuggerLog("DbSessionBase Dispose");
            }
            protected abstract DbDataAdapter GetDbDataAdapter();

            public abstract DbStatement GetStatement(string sqlQuery = "");
            public DataSet ExecuteDataSet(DbStatement stmt)
            {
                try
                {
                    Stopwatch stopWatch = new Stopwatch();
                    DataSet dataSet = new DataSet();
                    using (DbDataAdapter dbDataAdapter = this.GetDbDataAdapter())
                    {
                        stopWatch.Start();
                        this.PrepareDbCommand(stmt);
                        dbDataAdapter.SelectCommand = stmt.DbCommand;
                        int i = dbDataAdapter.Fill(dataSet);
                        stopWatch.Stop();
                        UtilityLog.DebuggerLog($"\n{stmt.DbCommand.CommandText}\n{MethodBase.GetCurrentMethod().Name} {stopWatch.ElapsedMilliseconds}ms effect {i} rows");
                        foreach (DbParameter dbParameter in stmt.DbCommand.Parameters)
                        {
                            UtilityLog.DebuggerLog($"{dbParameter.ParameterName} = {dbParameter.Value}");
                        }
                    }
                    return dataSet;
                }
                catch (Exception ex)
                {
                    UtilityLog.ErrorLog(ex);
                    throw new Exception("ssp4g ExecuteDataSet error" + ex.Message);
                }
            }
            public void BeginTransaction()
            {
                UtilityLog.DebuggerLog("Transaction Begin!");
                this.trans = this.conn.BeginTransaction();
            }
            public DataSet ExecuteDataSet(DbStatement stmt, string tableName)
            {
                try
                {
                    Stopwatch stopWatch = new Stopwatch();
                    DataSet dataSet = new DataSet();
                    using (DbDataAdapter dbDataAdapter = this.GetDbDataAdapter())
                    {
                        stopWatch.Start();
                        this.PrepareDbCommand(stmt);
                        dbDataAdapter.SelectCommand = stmt.DbCommand;
                        UtilityLog.DebuggerLog(stmt.DbCommand.CommandText);
                        int i = dbDataAdapter.Fill(dataSet, tableName);
                        stopWatch.Stop();
                        UtilityLog.DebuggerLog($"{MethodBase.GetCurrentMethod().Name} {stopWatch.ElapsedMilliseconds}ms effect {i} rows");

                    }
                    return dataSet;
                }
                catch (Exception ex)
                {
                    UtilityLog.ErrorLog(ex);
                    throw new Exception("ssp4g ExecuteDataSet error" + ex.Message);
                }
            }

            public DataTable ExecuteDataTable(DbStatement stmt)
            {
                Stopwatch stopWatch = new Stopwatch();
                try
                {
                    stopWatch.Start();
                    DataTable dataTable = new DataTable();
                    int i ;
                    using (DbDataAdapter dbDataAdapter = this.GetDbDataAdapter())
                    {
                        this.PrepareDbCommand(stmt);
                        dbDataAdapter.SelectCommand = stmt.DbCommand;
                        //print stmt .DbCommand.Parameters
                        string logMessage = PrepareLogMessage(stmt.DbCommand.Parameters);                        
                        i = dbDataAdapter.Fill(dataTable);
                        stopWatch.Stop();
                        UtilityLog.DebuggerLog($"\n{stmt.DbCommand.CommandText}\n{logMessage}\n{MethodBase.GetCurrentMethod().Name} {stopWatch.ElapsedMilliseconds}ms effect {i} rows");
                    }
                    return dataTable;
                }
                catch (Exception ex)
                {
                    UtilityLog.ErrorLog(ex);
                    throw new Exception("ssp4g ExecuteDataTable error \n" + ex.Message + $"\nSource SQL:\n{stmt.DbCommand.CommandText}");
                }
            }
            public async Task<DataTable> ExecuteDataTableAsync(DbStatement stmt, int times = 0)
            {
                Stopwatch stopWatch = new Stopwatch();
                int MaxRetries = 2;  // 最大重試次數
                int RetryDelayMs = 50;  // 重試等待時間
                try
                {
                    if (times > MaxRetries)
                    {
                        throw new Exception($"ssp4g ExecuteDataTableAsync 重新嘗試超過限制 (最大重試次數: {MaxRetries})");
                    }

                    DataTable dataTable = new DataTable();
                    await this.PrepareDbCommandAsync(stmt);
                    using (var reader = await ExecuteReaderAsync(stmt))
                    {
                        int affectedRows = 0;
                        if (reader.HasRows)
                        {
                            dataTable.Load(reader);
                            affectedRows = dataTable.Rows.Count;
                        }
                        if (!reader.IsClosed)
                        {
                            reader.Close();
                        }
                    }

                    return dataTable;
                }
                catch (Exception ex)
                {
                    times += 1;

                    if (times == MaxRetries)
                    {
                        UtilityLog.ErrorLog($"ExecuteDataTableAsync 已嘗試第{times}/{MaxRetries}", ex);
                    }
                    if (times < MaxRetries)
                    {
                        await Task.Delay(RetryDelayMs * (times));  // 使用遞增等待時間 10 
                        return await ExecuteDataTableAsync(stmt, times);
                    }

                    throw;
                }
            }



            public DataTable ExecuteDataTable(DbStatement stmt, string tableName)
            {
                DataSet dataSet = new DataSet();
                using (DbDataAdapter dbDataAdapter = this.GetDbDataAdapter())
                {
                    this.PrepareDbCommand(stmt);
                    dbDataAdapter.SelectCommand = stmt.DbCommand;
                    dbDataAdapter.Fill(dataSet, tableName);
                }
                return dataSet.Tables[tableName];
            }


            public int ExecuteNonQuery(DbStatement stmt)
            {
                Stopwatch stopWatch = new Stopwatch();
                this.PrepareDbCommand(stmt);                 
                using (DbTransaction dbTransaction = this.conn.BeginTransaction())
                {
                    stmt.DbCommand.Transaction = dbTransaction;
                    try
                    {
                        stopWatch.Start();
                        string logMessage = PrepareLogMessage(stmt.DbCommand.Parameters);
                        int i = stmt.DbCommand.ExecuteNonQuery();
                        dbTransaction.Commit();
                        stopWatch.Stop();
                        UtilityLog.DebuggerLog($"\n{stmt.DbCommand.CommandText}\n{logMessage}\n{MethodBase.GetCurrentMethod().Name} {stopWatch.ElapsedMilliseconds}ms effect {i} rows");
                        return i;
                    }
                    catch (Exception ex)
                    {
                        dbTransaction.Rollback();
                        UtilityLog.ErrorLog(ex + "\n" + stmt.DbCommand.CommandText + "\n" + PrepareLogMessage(stmt.DbCommand.Parameters));
                        throw new Exception("ssp4g ExecuteNonQuery error " + ex.Message);
                    }
                    finally
                    {
                        dbTransaction.Dispose();

                    }
                }
            }
            public async Task<int> ExecuteNonQueryAsync(DbStatement stmt)
            {
                Stopwatch stopWatch = new Stopwatch();
                this.PrepareDbCommand(stmt);
                using (DbTransaction dbTransaction = this.conn.BeginTransaction())
                {
                    stmt.DbCommand.Transaction = dbTransaction;
                    try
                    {
                        stopWatch.Start();
                        string logMessage = PrepareLogMessage(stmt.DbCommand.Parameters);
                        UtilityLog.DebuggerLog($"ExecuteNonQueryAsync Show Para \n {logMessage}");
                        int i = await stmt.DbCommand.ExecuteNonQueryAsync();
                        dbTransaction.Commit();
                        stopWatch.Stop();
                        UtilityLog.DebuggerLog($"ExecuteNonQueryAsync SQL:\n{stmt.DbCommand.CommandText}\n{stopWatch.ElapsedMilliseconds}ms effect {i} rows");
                        return i;
                    }
                    catch (Exception ex)
                    {
                        dbTransaction.Rollback();
                        UtilityLog.ErrorLog(ex);
                        throw new Exception("ssp4g ExecuteNonQueryAsync error" + ex.Message);
                    }
                    finally
                    {
                        dbTransaction.Dispose();

                    }
                }
            }


            public DbDataReader ExecuteReader(DbStatement stmt)
            {
                Stopwatch stopWatch = new Stopwatch();
                stopWatch.Start();
                this.PrepareDbCommand(stmt);
                var dr = stmt.DbCommand.ExecuteReader();
                stopWatch.Stop();
                string logMessage = PrepareLogMessage(stmt.DbCommand.Parameters);
                UtilityLog.DebuggerLog($"ExecuteReader {stmt.DbCommand.CommandText}\nShow Para\n{logMessage}{stopWatch.ElapsedMilliseconds}ms");
                return dr;
            }
            public async Task<DbDataReader> ExecuteReaderAsync(DbStatement stmt)
            {
                Stopwatch stopWatch = new Stopwatch();
                stopWatch.Start();

                if (stmt.DbCommand.Connection.State != ConnectionState.Open)
                {
                    await stmt.DbCommand.Connection.OpenAsync();
                }
                var dr = await stmt.DbCommand.ExecuteReaderAsync();
                stopWatch.Stop();
                string logMessage = PrepareLogMessage(stmt.DbCommand.Parameters);
                if (logMessage != string.Empty)
                {
                    UtilityLog.DebuggerLog($"\nExecuteReaderAsync {stopWatch.ElapsedMilliseconds}ms\n{stmt.DbCommand.CommandText}\n[Show Para]\n{logMessage}");
                }
                else
                {
                    UtilityLog.DebuggerLog($"\nExecuteReaderAsync {stopWatch.ElapsedMilliseconds}ms\n{stmt.DbCommand.CommandText}\n");
                }

                return dr;
            }

            public object ExecuteScalar(DbStatement stmt)
            {
                this.PrepareDbCommand(stmt);
                return stmt.DbCommand.ExecuteScalar();
            }
            public async Task<object> ExecuteScalarAsync(DbStatement stmt)
            {
                await this.PrepareDbCommandAsync(stmt);

                return await stmt.DbCommand.ExecuteScalarAsync();
            }
            private string PrepareLogMessage(DbParameterCollection parameters)
            {
                StringBuilder message = new StringBuilder();
                foreach (DbParameter dbParameter in parameters)
                {
                    message.AppendLine($"{dbParameter.ParameterName} = {dbParameter.Value}");
                }
                return message.ToString();
            }
        }
    }
}

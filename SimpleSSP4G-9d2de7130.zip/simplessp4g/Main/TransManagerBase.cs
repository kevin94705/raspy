﻿namespace simpleSSP4G
{
    public class TransManagerBase
    {
    }
}
﻿using System;

namespace simpleSSP4G
{
    public class EntityAttribute : Attribute
    {
        public string Table { get; set; }
    }
}
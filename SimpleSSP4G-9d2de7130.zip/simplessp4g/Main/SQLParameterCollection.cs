﻿using Oracle.ManagedDataAccess.Client;
using System.Collections;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data;

namespace simpleSSP4G
{
    public class SQLParameterCollection : abstractDbParameterCollection
    {
        public override bool IsFixedSize
        {
            get
            {
                return ((SqlParameterCollection)this.parameters).IsFixedSize;
            }
        }

        public override bool IsReadOnly
        {
            get
            {
                return ((SqlParameterCollection)this.parameters).IsReadOnly;
            }
        }

        public override bool IsSynchronized
        {
            get
            {
                return ((SqlParameterCollection)this.parameters).IsSynchronized;
            }
        }

        public override object SyncRoot
        {
            get
            {
                return ((SqlParameterCollection)this.parameters).SyncRoot;
            }
        }

        public SQLParameterCollection(SqlParameterCollection col) : base(col)
        {
        }

        public override OracleParameter Add(OracleParameter value)
        {
            throw new System.Exception("当前DbSession不是OracleClientSession，不能调用DbParameterCollection.Add(OracleParameter value)方法。");
        }

        public override SqlParameter Add(SqlParameter value)
        {
            ((SqlParameterCollection)this.parameters).Add(value);
            return value;
        }

        public override int Add(object value)
        {
            return this.parameters.Add(value);
        }

        public override DbParameter Add(string parameterName, object value)
        {
            return ((SqlParameterCollection)this.parameters).AddWithValue(parameterName, value);
        }

        public override DbParameter Add(string parameterName, DbType dbType, object value)
        {
            SqlParameter sqlParameter = ((SqlParameterCollection)this.parameters).AddWithValue(parameterName, value);
            sqlParameter.DbType = dbType;
            return sqlParameter;
        }

        public override DbParameter Add(string parameterName, DbType dbType, int size, object value)
        {
            SqlParameter sqlParameter = ((SqlParameterCollection)this.parameters).AddWithValue(parameterName, value);
            sqlParameter.DbType = dbType;
            sqlParameter.Size = size;
            return sqlParameter;
        }

        public override DbParameter Add(string parameterName, DbType dbType, int size, string sourceColumn)
        {
            SqlParameter sqlParameter = ((SqlParameterCollection)this.parameters).AddWithValue(parameterName, null);
            sqlParameter.DbType = dbType;
            sqlParameter.Size = size;
            sqlParameter.SourceColumn = sourceColumn;
            return sqlParameter;
        }

        public override DbParameter Add(string parameterName, DbType dbType, int size, ParameterDirection direction, object value)
        {
            SqlParameter sqlParameter = ((SqlParameterCollection)this.parameters).AddWithValue(parameterName, value);
            sqlParameter.DbType = dbType;
            sqlParameter.Size = size;
            sqlParameter.Direction = direction;
            return sqlParameter;
        }

        public override IEnumerator GetEnumerator()
        {
            return ((SqlParameterCollection)this.parameters).GetEnumerator();
        }
    }
}
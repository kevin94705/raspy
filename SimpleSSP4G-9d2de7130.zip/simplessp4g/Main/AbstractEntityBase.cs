﻿

using System.Collections;
using System.Collections.Generic;
using System.Data;

namespace simpleSSP4G
{
    /// <summary>
    /// entity CRUD 方法
    /// </summary>
    public abstract class AbstractEntityBase
    {
        public abstract IEnumerable<T> Select<T>(T e) where T : class, new();
        public abstract int Insert<T>(T e) where T : class, new();
        public abstract int Update<T>(T e) where T : class, new();

        public abstract int Delete<T>(T e) where T : class, new();

    }
}
﻿using System;
using System.Collections.Concurrent;

namespace simpleSSP4G
{
    /// <summary>
    /// 管理並建立與DB Manager相關實例的建立與否
    /// </summary>
    public class Apc
    {
        /// <summary>
        /// 使用thread-safe Dictionary class
        /// </summary>
        private readonly ConcurrentDictionary<Type, object> _cache = new ConcurrentDictionary<Type, object>();
        /// <summary>
        /// 建立無參數的class 並儲存於_chahe
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public T GetManager<T>()
        {
            return (T)_cache.GetOrAdd(typeof(T), _ => {
                return Activator.CreateInstance(typeof(T));
            });
           
            
        }
        /// <summary>
        /// 傳入Manager 類型及建構子參數，檢查是否已有實例，有的話就回傳，否則建立並快取。
        /// </summary>
        /// <typeparam name="T">Manager 類型</typeparam>
        /// <param name="constructorArgs">建構子參數</param>
        /// <returns>Manager 實例</returns>
        public T GetManager<T>(params object[] constructorArgs)
        {
            return (T)_cache.GetOrAdd(typeof(T), _ =>
            {
                try
                {
                    UtilityLog.InfoLog($"[Apc] Created new instance of {_.Name} with args: {string.Join(", ", constructorArgs)}");
                    if (constructorArgs.Length == 0) 
                    {
                        return Activator.CreateInstance(typeof(T));
                    }                   
                    return Activator.CreateInstance(typeof(T), constructorArgs);
                }
                catch (Exception ex)
                {
                    
                    throw new InvalidOperationException($"建立 {typeof(T).FullName} 實例時失敗。", ex);
                }
            });
        }

        public Apc() { }

    }
}
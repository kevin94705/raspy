﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data;

namespace simpleSSP4G
{
    public class OraParameterCollection : abstractDbParameterCollection
    {

        public override bool IsFixedSize
        {
            get
            {
                return ((OracleParameterCollection)this.parameters).IsFixedSize;
            }
        }

        public override bool IsReadOnly
        {
            get
            {
                return ((OracleParameterCollection)this.parameters).IsReadOnly;
            }
        }

        public override bool IsSynchronized
        {
            get
            {
                return ((OracleParameterCollection)this.parameters).IsSynchronized;
            }
        }

        public override object SyncRoot
        {
            get
            {
                return ((OracleParameterCollection)this.parameters).SyncRoot;
            }
        }

        public OraParameterCollection(OracleParameterCollection col) : base(col)
        {
        }

        public override OracleParameter Add(OracleParameter value)
        {
            return ((OracleParameterCollection)this.parameters).Add(value);
        }


        public override SqlParameter Add(SqlParameter value)
        {
            throw new Exception("当前DbSession不是SqlClientSession，不能调用DbParameterCollection.Add(SqlParameter value)方法。");
        }

        public override int Add(object value)
        {
            return ((OracleParameterCollection)this.parameters).Add(value);
        }

        public override DbParameter Add(string parameterName, object value)
        {
            //UtilityLog.InfoLog($"parameterName {parameterName} value {value}");
            try
            {
                if (parameterName.StartsWith("@"))
                {
                    UtilityLog.ErrorLog("Oracle.ManagedDataAccess OracleParameterCollection.Add方法不支持以@開頭的參數名稱。請使用:");
                    parameterName.Replace("@", ":");
                }

                return ((OracleParameterCollection)this.parameters).Add(parameterName, value);
            }
            catch (Exception EX)
            {
                UtilityLog.InfoLog(EX.Message);
                return null;
            }
        }

        public override DbParameter Add(string parameterName, DbType dbType, object value)
        {
            try
            {
                OracleParameter oleDbParameter = ((OracleParameterCollection)this.parameters).Add(parameterName, value);
                oleDbParameter.DbType = dbType;
                return oleDbParameter;
            }
            catch (Exception EX)
            {
                UtilityLog.InfoLog(EX.Message);
                throw;
            }
        }

        public override DbParameter Add(string parameterName, DbType dbType, int size, object value)
        {
            OracleParameter oleDbParameter = ((OracleParameterCollection)this.parameters).Add(parameterName, value);
            oleDbParameter.DbType = dbType;
            oleDbParameter.Size = size;
            return oleDbParameter;
        }

        public override DbParameter Add(string parameterName, DbType dbType, int size, string sourceColumn)
        {
            OracleParameter oleDbParameter = ((OracleParameterCollection)this.parameters).Add(parameterName, null);
            oleDbParameter.DbType = dbType;
            oleDbParameter.Size = size;
            oleDbParameter.SourceColumn = sourceColumn;
            return oleDbParameter;
        }

        public override DbParameter Add(string parameterName, DbType dbType, int size, ParameterDirection direction, object value)
        {
            OracleParameter oleDbParameter = ((OracleParameterCollection)this.parameters).Add(parameterName, value);
            oleDbParameter.DbType = dbType;
            oleDbParameter.Size = size;
            oleDbParameter.Direction = direction;
            return oleDbParameter;
        }


        public override IEnumerator GetEnumerator()
        {
            return ((OracleParameterCollection)this.parameters).GetEnumerator();
        }
    }
}
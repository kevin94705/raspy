﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
/// <summary>
/// create by kevin@2023 BPM
///</summary>

namespace simpleSSP4G
{
    public static class EntityHelper
    {
        public enum DBTransactionOperation
        {
            Select,
            Update,
            Insert,
            Delete

        }
        /// <summary>
        /// 會依據傳進來的<T>中類型的屬性名稱，
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns>
        /// 對應到資料庫中的欄位名稱回傳一個Dictionary 格式為 <Entity屬性名稱,DB欄位名稱>
        /// </returns>
        public static Dictionary<string, string> GetColumnMappings<T>()
        {
            UtilityLog.DebuggerLog($"GetColumnMappings Type:[{typeof(T)}]");
            Dictionary<string, string> columnMappings = new Dictionary<string, string>();

            foreach (PropertyInfo property in typeof(T).GetProperties())
            {
                var columnAttribute = property.GetCustomAttribute<PropertyAttribute>();

                if (columnAttribute != null)
                {
                    string columnName = columnAttribute.Column;

                    if (!string.IsNullOrEmpty(columnName))
                    {
                        columnMappings[property.Name] = columnName;
                    }
                }
            }

            return columnMappings;
        }
        /// <summary>
        /// 轉換輸入的datarow依據輸入的type設定參數並回傳需要的class物件
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dataRow"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public static T GetEntityFromDataRow<T>(DataRow dataRow) where T : new()
        {
            if (dataRow == null)
            {
                throw new ArgumentNullException(nameof(dataRow), "DataRow is null");
            }

            T entity = new T();
            var logMessages = new StringBuilder();
            logMessages.AppendLine($"start set {typeof(T).Name}");
            try
            {
                var type = typeof(T);
                foreach (PropertyInfo property in type.GetProperties())
                {
                    var columnAttribute = property.GetCustomAttribute<PropertyAttribute>();
                    if (columnAttribute == null || string.IsNullOrEmpty(columnAttribute.Column))
                        continue;

                    if (!dataRow.Table.Columns.Contains(columnAttribute.Column))
                        continue;

                    object value = dataRow[columnAttribute.Column];
                    if (value == DBNull.Value)
                    {
                        // 特殊處理 DBNull
                        HandleDbNullValue(property, entity, logMessages);
                        continue;
                    }

                    bool success = TrySetPropertyValue(property, entity, value, logMessages);
                    if (!success)
                    {
                        logMessages.AppendLine($"Could not convert {property.Name}: {value} from {value.GetType()} to {property.PropertyType}");
                    }
                }
                #if DEBUG
                UtilityLog.DebuggerLog(logMessages.ToString());
                #endif
                return entity;
            }
            catch (Exception ex)
            {
                UtilityLog.ErrorLog(ex);
                throw new Exception($"GetEntityFromDataRow Exception: {ex.Message}");
            }
        }
        private static void HandleDbNullValue(PropertyInfo property, object entity, StringBuilder logMessages)
        {
            if (property.PropertyType == typeof(string))
            {
                property.SetValue(entity, string.Empty);
                logMessages.AppendLine($"SET {property.Name} to empty string");
            }
            else if (property.PropertyType.IsGenericType &&
                     property.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>))
            {
                property.SetValue(entity, null);
                logMessages.AppendLine($"SET {property.Name} to null");
            }
        }

        private static bool TrySetPropertyValue(PropertyInfo property, object entity, object value, StringBuilder logMessages)
        {
            try
            {
                // 直接處理可空型別的轉換
                if (property.PropertyType.IsGenericType &&
                    property.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>))
                {
                    Type underlyingType = Nullable.GetUnderlyingType(property.PropertyType);

                    // 如果值已經是目標底層類型，直接設置
                    if (value.GetType() == underlyingType)
                    {
                        property.SetValue(entity, value);
                        logMessages.AppendLine($"SET {property.Name}: {value}");
                        return true;
                    }

                    // 嘗試顯式轉換
                    var convertedValue = Convert.ChangeType(value, underlyingType);
                    property.SetValue(entity, convertedValue);
                    logMessages.AppendLine($"Converted {property.Name} from {value.GetType()} to {property.PropertyType}");
                    return true;
                }

                // 原有的精確型別匹配
                if (value.GetType() == property.PropertyType)
                {
                    property.SetValue(entity, value);
                    logMessages.AppendLine($"SET {property.Name}: {value}");
                    return true;
                }

                // 常規型別轉換
                var standardConvertedValue = Convert.ChangeType(value, property.PropertyType);
                property.SetValue(entity, standardConvertedValue);
                logMessages.AppendLine($"Converted {property.Name} from {value.GetType()} to {property.PropertyType}");
                return true;
            }
            catch (Exception ex)
            {
                logMessages.AppendLine($"Conversion failed for {property.Name}: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// 轉換輸入的物件型態如果型態包含nullable 傳換成不包含nullable的純粹型態方便映射到資料庫資料型態
        /// Property.PropertyType[System.Nullable`1[System.Decimal]] CONVERT TO value TYPE [System.Decimal]
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="value"></param>
        /// <returns></returns>
        public static T NullableChangeType<T>(object value)
        {
            var t = typeof(T);

            if (t.IsGenericType && t.GetGenericTypeDefinition().Equals(typeof(Nullable<>)))
            {
                if (value == null)
                {
                    return default(T);
                }

                t = Nullable.GetUnderlyingType(t);
            }

            return (T)Convert.ChangeType(value, t);
        }

        /// <summary>
        /// !僅支援 where條件一個 快速建立insert 或是update 先確保T只有一個primarykey=true 只會將Entity.value !=null的欄位加入SQL中也必須確保primarykey有值
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="entity"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public static DbStatement DBTransationGenSQL<T>(T entity, DBTransactionOperation type, DbStatement stmt)
        {
            if (entity == null)
                throw new ArgumentNullException(nameof(entity));
            if (stmt == null)
                throw new ArgumentNullException(nameof(DbStatement));
            var columnAndValue = propertyConvertToStringDictionary(entity);
            var tableName = getEntityTableName<T>();
            var primaryKeyPair = getPrimaryKeyAndColumnName<T>()?.FirstOrDefault();
            var PrimaryColumnName = primaryKeyPair?.Value?? string.Empty;
            var PrimaryName = primaryKeyPair?.Key??string.Empty;
            var parameterPrefix = stmt.Seq;
            var sql = new StringBuilder();
            var logMessage = new StringBuilder();
            switch (type)
            {
                case DBTransactionOperation.Select:
                    sql.Append($"SELECT * FROM {tableName} WHERE {PrimaryColumnName}={parameterPrefix}{PrimaryColumnName}");
                    break;

                case DBTransactionOperation.Update:
                    sql.Append($"UPDATE {tableName} SET ");
                    var updateColumns = columnAndValue
                        .Where(x => x.Key != PrimaryColumnName)
                        .Select(x => $"{x.Key}={parameterPrefix}{x.Key}");
                    sql.Append(string.Join(", ", updateColumns));
                    sql.Append($" WHERE {PrimaryColumnName}={parameterPrefix}{PrimaryColumnName}");
                    break;

                case DBTransactionOperation.Insert:
                    sql.Append($"INSERT INTO {tableName} (");
                    sql.Append(string.Join(", ", columnAndValue.Keys));
                    sql.Append(") VALUES (");
                    sql.Append(string.Join(", ", columnAndValue.Keys.Select(x => $"{parameterPrefix}{x}")));
                    sql.Append(")");
                    break;
                case DBTransactionOperation.Delete:
                    sql.Append($"Delete {tableName} ");
                    sql.Append($" WHERE {PrimaryColumnName}={parameterPrefix}{PrimaryColumnName}");
                    break ;
                default:
                    UtilityLog.ErrorLog($"{nameof(type)}缺少此類型{type}");
                    throw new ArgumentException($"Unsupported operation type: {type}", nameof(type));
            }            
            logMessage.AppendLine($"DBTransationGenSQL {type} result \n{sql}");
            // Add parameters
            foreach (var item in columnAndValue)
            {
                switch (type)
                {
                    case DBTransactionOperation.Select:
                    case DBTransactionOperation.Insert:
                    case DBTransactionOperation.Update:
                        if (item.Value != null)
                        {
                            stmt.Parameters.Add($"{parameterPrefix}{item.Key}", item.Value);
                            logMessage.AppendLine($"{parameterPrefix}{item.Key}{item.Value}");
                        }
                        break;
                    case DBTransactionOperation.Delete:                    
                        if (item.Value != null && PrimaryColumnName.Contains(item.Key))
                        {
                            stmt.Parameters.Add($"{parameterPrefix}{item.Key}", item.Value);
                            logMessage.AppendLine($"{parameterPrefix}{item.Key}{item.Value}");                            
                        }
                        break;
                }       
            }
            if (stmt.Parameters.Count<= 0&& (type!= DBTransactionOperation.Select|| type!= DBTransactionOperation.Insert)) {
                UtilityLog.ErrorLog(logMessage.ToString());
                throw new ArgumentException("非select insert 交易必須要有設定主鍵參數才可以產生SQL");
            }
#if DEBUG
            UtilityLog.DebuggerLog("來自EntityHelper產生的SQL\n"+logMessage.ToString());
#endif
            stmt.CommandText = sql.ToString();
            return stmt;
        }

        public static DbStatement DBTransationGenSQL<T>(T entity, DBTransactionOperation type, DbStatement stmt, List<string> whereColumns) 
        {
            if (entity == null)
                throw new ArgumentNullException(nameof(entity));
            if (stmt == null)
                throw new ArgumentNullException(nameof(stmt));
            if (whereColumns == null) 
            {
                //沒有提供WHERE就走抓PRIMARY COLUMN 的方式
                return DBTransationGenSQL(entity, type,stmt);
            }
            var columnAndValue = propertyConvertToStringDictionary(entity);
            var tableName = getEntityTableName<T>();
            var primaryKeyPair = getPrimaryKeyAndColumnName<T>()?.FirstOrDefault();
            var parameterPrefix = stmt.Seq;
            var sql = new StringBuilder();
            var logMessage = new StringBuilder();

            // 驗證whereColumns是否有效
            if (whereColumns != null && whereColumns.Count > 0)
            {
                // 過濾掉無效的(沒有設定value)的wherewu條件列
                var validWhereColumns = whereColumns
                    .Where(col => columnAndValue.ContainsKey(col) && columnAndValue[col] != null)
                    .ToList();

                if (validWhereColumns.Count == 0)
                {
                    // 如果没有有效的where条件列，则回退到使用主键
                    whereColumns = null;
                }
                else
                {
                    // 更新为有效的列
                    whereColumns = validWhereColumns;
                }
            }

            switch (type)
            {
                case DBTransactionOperation.Select:
                    sql.Append($"SELECT * FROM {tableName}");

                    // 构建WHERE子句
                    if (whereColumns != null && whereColumns.Count > 0)
                    {
                        sql.Append(" WHERE ");
                        sql.Append(string.Join(" AND ", whereColumns.Select(col =>
                            $"{col}={parameterPrefix}{col}")));
                    }
                    break;

                case DBTransactionOperation.Update:
                    sql.Append($"UPDATE {tableName} SET ");

                    // 创建非WHERE条件的更新列
                    var nonWhereColumns = columnAndValue.Keys.ToList();
                    if (whereColumns != null)
                    {
                        nonWhereColumns = nonWhereColumns.Except(whereColumns).ToList();
                    }

                    var updateColumns = nonWhereColumns
                        .Where(col => columnAndValue[col] != null)
                        .Select(col => $"{col}={parameterPrefix}{col}");

                    sql.Append(string.Join(", ", updateColumns));

                    // 构建UPDATE的WHERE子句
                    if (whereColumns != null && whereColumns.Count > 0)
                    {
                        sql.Append(" WHERE ");
                        sql.Append(string.Join(" AND ", whereColumns.Select(col =>
                            $"{col}={parameterPrefix}{col}")));
                    }
                    break;

                case DBTransactionOperation.Insert:
                    sql.Append($"INSERT INTO {tableName} (");
                    sql.Append(string.Join(", ", columnAndValue.Keys));
                    sql.Append(") VALUES (");
                    sql.Append(string.Join(", ", columnAndValue.Keys.Select(x => $"{parameterPrefix}{x}")));
                    sql.Append(")");
                    break;

                case DBTransactionOperation.Delete:
                    sql.Append($"DELETE FROM {tableName}");

                    // 构建DELETE的WHERE子句
                    if (whereColumns != null && whereColumns.Count > 0)
                    {
                        sql.Append(" WHERE ");
                        sql.Append(string.Join(" AND ", whereColumns.Select(col =>
                            $"{col}={parameterPrefix}{col}")));
                    }
                    break;

                default:
                    UtilityLog.ErrorLog($"{nameof(type)}缺少此類型{type}");
                    throw new ArgumentException($"Unsupported operation type: {type}", nameof(type));
            }

            logMessage.AppendLine($"DBTransationGenSQL {type} result \n{sql}");

            //添加參數
            foreach (var item in columnAndValue)
            {
                bool isWhereColumn = whereColumns != null && whereColumns.Contains(item.Key);
                if (item.Value != null&& isWhereColumn)
                {
                    stmt.Parameters.Add($"{parameterPrefix}{item.Key}", item.Value);
                    logMessage.AppendLine($"{parameterPrefix}{item.Key}={item.Value}");
                }
            }

            // 对于非SELECT/INSERT操作，确保我们有必要的参数
            if (stmt.Parameters.Count <= 0 &&
                (type != DBTransactionOperation.Select && type != DBTransactionOperation.Insert))
            {
                UtilityLog.ErrorLog(logMessage.ToString());
                throw new ArgumentException("非select insert 交易必須要有設定主鍵參數才可以產生SQL");
            }

#if DEBUG
            UtilityLog.DebuggerLog("來自EntityHelper產生的SQL\n" + logMessage.ToString());
#endif

            stmt.CommandText = sql.ToString();
            return stmt;

        }
        //只會將有值的加入字典回傳
        private static Dictionary<string, object> propertyConvertToStringDictionary<T>(T entity)
        {
            Dictionary<string, string> entityMapping = GetColumnMappings<T>();
            Dictionary<string, object> result = new Dictionary<string, object>();
            StringBuilder sb = new StringBuilder();
            var methodName = MethodBase.GetCurrentMethod().Name;
            foreach (var property in entity.GetType().GetProperties())
            {
                var propertyName = property.Name;
                var column = entityMapping.ContainsKey(propertyName) ? entityMapping[propertyName] : null;
                
                if (!string.IsNullOrEmpty(column) && property.GetValue(entity) != null)
                {
                    result.Add(column, property.GetValue(entity));
                    sb.AppendLine($"{methodName} Column mapping found for property [{propertyName}] [{property.GetValue(entity)}]");
                }
                else
                {
                    //依據現在的function name 寫成log
                    sb.AppendLine($"{methodName} Column mapping not found for property [{propertyName}]");
                }
            }
#if DEBUG
            UtilityLog.DebuggerLog($"{methodName}\n{sb}");
#endif
            return result;
        }
        public static string getEntityTableName<T>()
        {
            Type entityType = typeof(T);
            var tableAttribute = (EntityAttribute)Attribute.GetCustomAttribute(entityType, typeof(EntityAttribute));
            if (tableAttribute != null)
            {
                string tableName = tableAttribute.Table;
                return tableName;
            }
            return null;
        }

        public static List<string> GetWhereColumnsFromEntity<T>(T whereEntity) where T : class, new()
        {
            if (whereEntity == null)
                return null;            
            var result = new List<string>();
            var entityValues = propertyConvertToStringDictionary(whereEntity);

            // 只获取非空值的列作为WHERE条件
            foreach (var item in entityValues)
            {
                if (item.Value != null)
                {
                    result.Add(item.Key);
                }
            }

            return result.Count > 0 ? result : null;
        }
        /// <summary>
        /// 請確保T只有一個primary否則只會直接抓第一個當作primarykey
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public static string getPrimaryKeyName<T>()
        {
            var primaryKeyProperty = typeof(T).GetProperties()
                .FirstOrDefault(item =>
                    item.GetCustomAttribute<PropertyAttribute>()?.IsPrimaryKey == true);

            return primaryKeyProperty?.Name ?? string.Empty;
        }
        /// <summary>
        /// 請確保T只有一個primary否則只會直接抓第一個當作primarykey
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public static Dictionary<string, string> getPrimaryKeyAndColumnName<T>()
        {
            Dictionary<string, string> result = new Dictionary<string, string>();
            foreach (PropertyInfo item in typeof(T).GetProperties())
            {
                if (item.GetCustomAttribute<PropertyAttribute>().IsPrimaryKey == true)
                {
                    result.Add(item.Name, item.GetCustomAttribute<PropertyAttribute>().Column);
                    return result;
                }
            }
            return null;
        }
        /// <summary>
        /// 依據新的class T(必須有設定Property) 轉換成List<T>
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static IEnumerable<T> ConvertDataTableToList<T>(DataTable dt) where T : new()
        {
            List<T> data = new List<T>();
            if (dt != null)
            {
                foreach (DataRow row in dt.Rows)
                {
                    T item = GetEntityFromDataRow<T>(row);

                    data.Add(item);
                }
                #if DEBUG
                UtilityLog.DebuggerLog($"List<{typeof(T).Name}> created with {data.Count} items.");
                #endif
                return data;
            }
            else {
                return null;
            }
        }
        #region 兩個類別轉換
        /// <summary>
        /// 兩個相同繼承實體互相做轉換
        /// </summary>
        /// <typeparam name="TSource"></typeparam>
        /// <typeparam name="TDestination"></typeparam>
        /// <param name="source"></param>
        /// <returns></returns>
        public static TDestination ConvertSameBase<TSource, TDestination>(TSource source)
        where TSource : class
        where TDestination : class, new()
        {
            StringBuilder msg = new StringBuilder();
            var sourceBaseTypes = GetBaseTypes(typeof(TSource)).First();
            var destinationBaseTypes = GetBaseTypes(typeof(TDestination)).First();
            if (!sourceBaseTypes.Name.Equals(destinationBaseTypes.Name))
            {
#if DEBUG
                msg.AppendLine($"來源{typeof(TSource)}與目標{typeof(TDestination)}的class基底{sourceBaseTypes.Name}!={destinationBaseTypes.Name}不同無法直接做轉換，請手動轉換。");
                UtilityLog.ErrorLog($"{msg}");
#endif
                throw new ArgumentNullException($"{msg}");
            }
            if (source == null)
            {
                msg.AppendLine($"ApInterfaceTempManager's ConvertHEAD {typeof(TSource)} is null");
                UtilityLog.ErrorLog($"{msg}");
                throw new ArgumentNullException($"{msg}");
            }

            // 創建目標對象的實例
            TDestination destination = new TDestination();

            // 獲取源類別和目標類別的所有屬性
            PropertyInfo[] sourceProperties = typeof(TSource).GetProperties();
            PropertyInfo[] destinationProperties = typeof(TDestination).GetProperties();

            // 遍歷源類別的屬性
            foreach (var sourceProp in sourceProperties)
            {
                // 檢查是否有 Property 特性
                var sourcePropertyAttr = sourceProp.GetCustomAttribute<PropertyAttribute>();
                if (sourcePropertyAttr == null) continue;

                // 在目標類別中查找同名屬性
                var destProp = destinationProperties
                    .FirstOrDefault(p =>
                    {
                        var destPropAttr = p.GetCustomAttribute<PropertyAttribute>();
                        return destPropAttr != null &&
                               destPropAttr.Column == sourcePropertyAttr.Column;
                    });

                // 如果找到對應的屬性，進行值的複製
                if (destProp != null && destProp.CanWrite)
                {
                    try
                    {
                        object value = sourceProp.GetValue(source);
                        destProp.SetValue(destination, value);
                    }
                    catch (Exception ex)
                    {
                        // 可以添加日誌或特定的錯誤處理
                        msg.AppendLine($"轉換屬性 {sourceProp.Name} 時發生錯誤: {ex.Message}");
                        UtilityLog.ErrorLog($"{msg}");
                    }
                }
            }

            return destination;
        }
        /// <summary>
        /// 獲取type基底class名稱並排除本身class名稱回傳
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        private static IEnumerable<Type> GetBaseTypes(Type type)
        {
            var baseTypes = new List<Type>();

            // 添加直接基类
            if (type.BaseType != null && type.BaseType != typeof(object))
            {
                baseTypes.Add(type.BaseType);
            }

            // 添加实现的接口
            baseTypes.AddRange(type.GetInterfaces());

            return baseTypes;
        }

        #endregion

    }
}

﻿using Oracle.ManagedDataAccess.Client;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data;

namespace simpleSSP4G
{
    public abstract class abstractDbParameterCollection : DbParameterCollection
    {
        protected DbParameterCollection parameters;

        public override int Count
        {
            get
            {
                return this.parameters.Count;
            }
        }

        public abstract override bool IsFixedSize
        {
            get;
        }

        public abstract override bool IsReadOnly
        {
            get;
        }

        public abstract override bool IsSynchronized
        {
            get;
        }

        public abstract override object SyncRoot
        {
            get;
        }

        public abstractDbParameterCollection(DbParameterCollection col)
        {
            this.parameters = col;
        }

        public abstract OracleParameter Add(OracleParameter value);

        public abstract SqlParameter Add(SqlParameter value);

        public abstract DbParameter Add(string parameterName, object value);

        public abstract DbParameter Add(string parameterName, DbType dbType, object value);

        public abstract DbParameter Add(string parameterName, DbType dbType, int size, object value);

        public abstract DbParameter Add(string parameterName, DbType dbType, int size, string sourceColumn);

        public abstract DbParameter Add(string parameterName, DbType dbType, int size, ParameterDirection direction, object value);

        public DbParameter Add(string parameterName, OracleDbType dbType, object value)
        {
            OracleParameter oleDbParameter = ((OracleParameterCollection)this.parameters).Add(parameterName, value);
            oleDbParameter.OracleDbType = dbType;
            return oleDbParameter;
        }
        public DbParameter Add(string parameterName, OracleDbType dbType, ParameterDirection direction)
        {
            OracleParameter oleDbParameter = ((OracleParameterCollection)this.parameters).Add(parameterName, null);
            oleDbParameter.Direction = direction;
            oleDbParameter.OracleDbType = dbType;
            return oleDbParameter;
        }
        public DbParameter Add(string parameterName, OracleDbType dbType, int size, ParameterDirection direction, object value)
        {
            OracleParameter oleDbParameter = ((OracleParameterCollection)this.parameters).Add(parameterName, value);
            oleDbParameter.Direction = direction;
            oleDbParameter.OracleDbType = dbType;
            oleDbParameter.Size = size;
            return oleDbParameter;
        }
        public override void AddRange(System.Array values)
        {
            this.parameters.AddRange(values);
        }

        public override void Clear()
        {
            this.parameters.Clear();
        }

        public override bool Contains(object value)
        {
            return this.parameters.Contains(value);
        }

        public override bool Contains(string value)
        {
            return this.parameters.Contains(value);
        }

        public override void CopyTo(System.Array array, int index)
        {
            this.parameters.CopyTo(array, index);
        }

        public abstract override System.Collections.IEnumerator GetEnumerator();

        protected override DbParameter GetParameter(int index)
        {
            return this.parameters[index];
        }

        protected override DbParameter GetParameter(string parameterName)
        {
            return this.parameters[parameterName];
        }

        public override int IndexOf(object value)
        {
            return this.parameters.IndexOf(value);
        }

        public override int IndexOf(string parameterName)
        {
            return this.parameters.IndexOf(parameterName);
        }

        public override void Insert(int index, object value)
        {
            this.parameters.Insert(index, value);
        }

        public override void Remove(object value)
        {
            this.parameters.Remove(value);
        }

        public override void RemoveAt(int index)
        {
            this.parameters.RemoveAt(index);
        }

        public override void RemoveAt(string parameterName)
        {
            this.parameters.RemoveAt(parameterName);
        }

        protected override void SetParameter(int index, DbParameter value)
        {
            this.parameters[index].Value = value;
        }

        protected override void SetParameter(string parameterName, DbParameter value)
        {
            this.parameters[parameterName].Value = value;
        }
    }
}
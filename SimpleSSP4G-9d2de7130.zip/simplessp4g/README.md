﻿# SSP4G - 用於 DBContent 與 DataTable 轉換 Entity 物件

## 使用說明

**適用 .NET Framework >= 4.8**  
項目需安裝以下 NuGet 包：

- **Oracle.ManagedDataAccess >= 23.X**
- **NLog >= 5.3.4**
- **NLog.Extensions.Logging >= 5.3.14**

---

## 使用方法

### 方法 1：直接複製原始碼  
將 `main` 文件資料夾直接複製至專案中，並把原始碼編譯至專案中。

### 方法 2：引用 DLL  
將已編譯好的 DLL 文件增加至項目參考中。

---

## 範例程式

### 1. 設定連線字串

在 `web.config` 或 `app.config` 設定 (`connectionStrings`) dbcontent 會根據 `providerName` 建立不同的DBcontent。

```xml
<configuration>
  <connectionStrings>
    <add name="MSDB" 
         connectionString="Server=db;Database=db;uid=user;pwd=pass;MultipleActiveResultSets=True;" 
         providerName="System.Data.SqlClient"/>
    <add name="ora" 
         connectionString="Data Source=db;User Id=user;Password=pass;" 
         providerName="Oracle.ManagedDataAccess.Client"/>
  </connectionStrings>
</configuration>
```
### 2.繼承EntityDBBase檔案
fileA.cs
````CSharp
using simpleSSP4G;
public class VendorCodeOra : EntityDBBase//繼承simpleSSP4G 設定DB provider是誰
{
    //傳入config中的連線字串
    public VendorCodeOra(string Key) : base(Key) { }
}
````
### 3.初始化建立DBcontent物件
fileB.cs
````CSharp
public partial class VendorApply : Page
{
//可以直接在最前面就先宣告建立DBcontent
    VendorCodeOra ora = new VendorCodeOra("ora");
    VendorCodeMSSQL MSDB = new VendorCodeMSSQL("MSDB");

    protected void Page_Load(object sender, EventArgs e){...}
}
````
### 4.建立query function
#### 4.1快速建立query方法 `有參數` `同步`  EntityDBBase - `ExecuteWithAction`
fileA.cs
````cs
public class VendorCodeOra : EntityDBBase{
//初始化此方法如步驟2
    public DataTable GetVendorApplyHeadInfo(string VendorCode)
    {
        //使用:表示參數
        string sql = @"select PV.Attribute1 from PO_vendors PV where PV.segment1=:VendorCode";
        //使用EntityDBBase中的ExecuteWithAction加入參數
        return ExecuteWithAction(sql, stmt => stmt.Parameters.Add("VendorCode", VendorCode));
    }
}
````
#### 4.2快速建立query方法 `無參數` `非同步` EntityDBBase - `ExecuteQueryAsync`
fileA.cs
```cs
public class VendorCodeOra : EntityDBBase{
    public async Task<DataTable> GetFreightAsync()
    {
        string sql = @"SELECT  MEANING displayed_field , lookup_code 
                        FROM FND_LOOKUP_VALUES LV 
                        where lookup_type = 'FREIGHT TERMS' and sysdate < nvl(END_DATE_ACTIVE, sysdate + 1) 
                        order by upper(MEANING)";
        return await ExecuteQueryAsync(sql);
    }
}
```
#### 4.3快速建立query方法 `有參數` `非同步` EntityDBBase - `ExecuteWithActionAsync`
fileA.cs
```cs
public class VendorCodeOra : EntityDBBase{
    public async Task<DataTable> CheckVATisExistsInOrg(string VAT_Num, string Site)
    {
        string sql = @"select PVSA.Vat_Registration_Num ,org_id
                    from Po_Vendor_Sites_All PVSA , gmfg.ou_org_mapping_all OMA
                    where Vat_Registration_Num=:tax_number and PVSA.org_id=OMA.ou_id
                    and OMA.site=:Site ";
        return await ExecuteWithActionAsync(sql, (stmt, sqlBuilder) =>
        {
            stmt.Parameters.Add("tax_number", VAT_Num);
            stmt.Parameters.Add("Site", Site);
        });
    }
}
```

### 5. 建立Entity class
Entity.cs
- Property - 使用SSP4G 的Property定義的Column="DB欄位名稱"
```cs
using simpleSSP4G;
using System;
public class VendorQueryResultEntity
{
    [Property(Column = "Attribute11")]
    public string Attribute11 { get; set; }

    [Property(Column = "vendor_site_id")]
    public int VendorSiteId { get; set; }

    [Property(Column = "Inactive")]
    public DateTime? Inactive { get; set; }
    //other...
}
```

### 6.轉換成dataTable轉換成Entityclass
API.cs
- `EntityHelper.ConvertDataTableToList<Entityclass>(Datatable)`
```cs
[RoutePrefix("api/QueryAPI")]
public class QueryAPIController : ApiController
{
    private IHttpActionResult JsonResponse<T>(ApiResponse<T> response)
    {
        var json = JsonConvert.SerializeObject(response, Formatting.Indented);
        return Content(HttpStatusCode.OK, json, Configuration.Formatters.JsonFormatter);
    }
    [Route("QueryVendor")]
    [HttpGet]
    public async Task<IHttpActionResult> QueryVendor(string searchvendor, string TaxNumber, string GroupName)
    {
        try
        {
            VendorCodeOra ora = new VendorCodeOra("ora");
            DataTable dt = await ora.GetVendorQueryData(searchvendor, TaxNumber, GroupName);
            var json = EntityHelper.ConvertDataTableToList<VendorQueryResultEntity>(dt);
            return JsonResponse(ApiResponse<IEnumerable<VendorQueryResultEntity>>.CreateSuccess(json));
        }
        catch (Exception ex)
        {
            UtilityLog.ErrorLog(ex);
            return InternalServerError(ex);
        }
    }
}
```
# 進階
## 建立Manager使用Apc統一管理
`Apc` 是一個輕量級的物件容器（Container），會在每個 `HttpRequest` 中建立並快取特定的實體 (manager/service)，直到本次請求結束。可用來避免重複建立資料庫操作物件（如繼承 EntityDBBase 的 manager 類別）。
配合 `ApcProvider` 可實現「自動注入、統一管理、提升效能」。

## 使用方式
### 1.建立manager.cs    
```cs
public class Ora_Query_Manager : EntityDBBase
{
    /// <summary>
    /// key應要是ora 對應至web config
    /// </summary>
    /// <param name="Key"></param>
    public Ora_Query_Manager(string Key) : base(Key)
    {
        alterNLS();//因設置問題導致NLS不同查View 甚至有些PKG會沒東西 表會查不到....初始話就要執行才可以
    }
}
```
### 2.於需要的地方呼叫APC
```cs
var apc = ApcProvider.Current;

// 不同manager
var oraQuery = apc.GetManager<Ora_Query_Manager>("ora");

// 自動給預設 conn="ERPForm"
var formHeader = apc.GetManager<R_Yia_Form_apply_Header>("ERPForm");

```
